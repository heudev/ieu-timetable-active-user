const { connectDB } = require("./database");

module.exports = () => {
    connectDB();
};
